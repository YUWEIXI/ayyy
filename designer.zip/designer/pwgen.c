/*
 * A program that randomly generates a password and sets that as your password
 *
 */

#include <crypt.h>
#include <errno.h>
#include <getopt.h>
#include <limits.h>
#include <openssl/rand.h>
#include <pwd.h>
#include <shadow.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <fcntl.h>

#define FILENAME "/tmp/pwgen_random"
#define BUFF_SZ 2048
#define ARGS_FILENAME_SZ 52
#define FILENAME_SZ 1024
#define PASSWD_SZ 8
#define SALT_SZ 32
// 哈希类型
enum Hash {PW_DES, PW_MD5, PW_BLOWFISH, PW_SHA256, PW_SHA512};
// 参数结构体
typedef struct {
  // 是否写入 0 不写入 1 写入 
  unsigned char write;
  // 哈希类型 0-4
  unsigned char type;
  // 盐 32位
  char salt[SALT_SZ];
  // 文件名 1024位  
  char filename[FILENAME_SZ];
} pwgen_args;
// 全局变量
extern int errno;
// 全局变量--optarg
extern char *optarg;
// 全局变量--help
int help;
//  获取用户uid
static uid_t get_uid() {
  // 获取用户目录
  char* dir;
  // 获取用户信息
  struct passwd* pw;
  // 用户uid
  uid_t uid;
// 初始化uid  
  uid = 0;
  // 获取用户目录
  dir = getenv("HOME");
  // 设置用户信息
  setpwent();
  // 遍历用户信息
  while ((pw = getpwent()) != NULL) {
    // 如果用户目录匹配
    if (strcmp(pw->pw_dir, dir) == 0) {
      // 设置用户uid
      uid = pw->pw_uid;
      // 跳出循环
      break;
    }
  }
  // 关闭用户信息
  endpwent();
  // 返回用户uid
  return uid;
}

  // 获取用户gid
static gid_t get_gid() {
  // 获取用户目录
  char* dir;
  // 获取用户信息
  struct passwd* pw;
  // 用户gid
  gid_t gid;
  // 初始化gid
  gid = 0;
  // 获取用户目录
  dir = getenv("HOME");
  // 设置用户信息
  setpwent();
  // 遍历用户信息
  while ((pw = getpwent()) != NULL) {
    // 如果用户目录匹配
    if (strcmp(pw->pw_dir, dir) == 0) {
      // 设置用户gid
      gid = pw->pw_gid;
      // 跳出循环
      break;
    }
  }
  // 关闭用户信息
  endpwent();
  // 返回用户gid
  return gid;
}

// 获取用户名
static char* get_username() {
  // 获取用户信息
  struct passwd* pw;
  // 获取用户信息
  pw = getpwuid(get_uid());
  // 返回用户名
  return pw->pw_name;
}

// 检查tmp文件是否存在并具有正确的权限
// 返回 0 成功 -1 失败
static int check_perms() {
  struct stat buf;
  // 文件描述符
  FILE* fd;

  // 删除tmp文件
  unlink(FILENAME);
  // 检查文件是否存在
    if (lstat(FILENAME, &buf) == 0) {
    // 文件存在
    return -1;
  }
  // 创建文件
  fd = fopen(FILENAME, "w");
  // 关闭文件
  fclose(fd);
  // 设置文件权限
  chown(FILENAME, get_uid(), get_gid());
  // 返回0
  return 0;
}

// 获取熵
static void get_entropy(char* buffer) {
  int i, c;
  // 打印提示信息
  printf("Type stuff so I can gather entropy, Ctrl-D to end:\n");
  // 初始化i
  i = 0;

  // 为什么不是从我们自己的随机熵数据开始？
  strcpy(buffer, "u1,7Jnsd");
  i+=8;
  // 获取输入
  c = getc(stdin);
  while (i < BUFF_SZ-1) {
    // 如果输入结束
        if (c == EOF) return;
    // 将输入字符写入buffer
    buffer[i] = c;
    // 获取下一个字符
    c = getc(stdin);
    // 增加i
    i++;
  }
  buffer[i] = '\0';
}

// 写入熵到临时文件，因为我们懒
static void fill_entropy() {
  char buffer[BUFF_SZ];
  FILE* fd;

  get_entropy(buffer);
  fd = fopen(FILENAME, "w");
  fwrite(buffer, strlen(buffer), sizeof(char), fd);
  fclose(fd);
}

      // 将buffer转换为某种有意义的东西
//TODO: Fix this, this is a terrible hack   
static void convert_uc_c(unsigned char* buf, char* res, size_t size) {
  // 初始化i
  int i;
  // 初始化c
  unsigned char c;
  // 遍历buf
  for (i = 0; i < size; i++) {
    // 将buf[i]右移2位
    c = (buf[i] >> 2);
    // 如果c小于10
    if (c < 10)
      // 将c转换为字符
      res[i] = c + '0';
    // 如果c小于36
    else if (c < 36)
      // 将c转换为字符
      res[i] = (c-10) + 'A';
    // 如果c小于62
    else if (c < 62)
      // 将c转换为字符
      res[i] = (c-36) + 'a';
    // 如果c小于63
    else if (c < 63)
      // 将c转换为字符
      res[i] = '-';
    // 否则
    else
      // 将c转换为字符
      res[i] = '_'; 
  }
}

// 生成密码
static void gen_passwd(pwgen_args args, char* passwd) {
  unsigned char buffer[PASSWD_SZ];

  RAND_load_file(args.filename, -1);
  RAND_bytes(buffer, PASSWD_SZ);
  convert_uc_c(buffer, passwd, PASSWD_SZ);
}

// 生成伪盐
static void gen_salt(char* salt) {
  unsigned char buffer[SALT_SZ];

  RAND_bytes(buffer, SALT_SZ);
  convert_uc_c(buffer, salt, SALT_SZ);
}

// 生成密码的哈希
static char* gen_crypt(pwgen_args args, char* password) {
  // 盐 4+32+1
  char salt[4+SALT_SZ+1], *ptr;
  // 盐长度
  size_t salt_sz = SALT_SZ;

  // 初始化ptr
    ptr = salt;
  // 初始化salt
  memset(salt, 0, sizeof(salt));
  // 根据哈希类型设置盐
  switch(args.type) {
    // 哈希类型为MD5
    case PW_MD5:
      // 将ptr加上"$1$"
      ptr += sprintf(ptr, "$1$");
      break;
    // 哈希类型为Blowfish
      case PW_BLOWFISH:
      // 将ptr加上"$2a$"
      ptr += sprintf(ptr, "$2a$");
      break;
    // 哈希类型为SHA256
      ptr += sprintf(ptr, "$5$");
      break;
    // 哈希类型为SHA512
    case PW_SHA512:
      // 将ptr加上"$6$"
      ptr += sprintf(ptr, "$6$");
      break;
    // 哈希类型为DES
    default:
      // DES只使用2个字符的盐？
      salt_sz = 2;
  }

  strncpy(ptr, args.salt, salt_sz);
  return crypt(password, salt);
}

// 更新/etc/shadow中的条目
static void update_spent(char* crypt) {
  FILE *old, *new;
  struct spwd *spw, spw_copy;
  char* username;

  int old_fd, new_fd;

  // 获取锁
  if(lckpwdf() != 0){
    // 打印错误信息
    printf("could not obtain lock on shadow file\n");
    // 退出程序
    exit(1);
  }

  // 创建/etc/shadow的备份
  link("/etc/shadow", "/etc/shadow~");
  // 删除/etc/shadow
  unlink("/etc/shadow");

  // 打开/etc/shadow的备份
  old_fd = open("/etc/shadow~", O_RDONLY,  S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH);
  // 创建/etc/shadow
  new_fd = open("/etc/shadow", O_CREAT | O_RDWR | O_EXCL,  S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH);
  // 打开/etc/shadow的备份
  old = fdopen(old_fd, "r");
  // 创建/etc/shadow
  new = fdopen(new_fd, "w");

  // 打印提示信息
  printf("opening shadow files\n");
  // 获取用户名
  username = get_username();
  // 获取用户信息
  spw = fgetspent(old);

  // 遍历/etc/shadow
  while (spw != NULL) {
    // 如果用户名匹配
    if (strcmp(username, spw->sp_namp) == 0) {
      // 复制用户信息
      memcpy(&spw_copy, spw, sizeof(struct spwd));
      // 设置密码
      spw_copy.sp_pwdp = crypt;
      // 写入用户信息
      putspent(&spw_copy, new);
      // 清空用户信息
      memset(&spw_copy, 0, sizeof(struct spwd));
    } else {
      // 写入用户信息
      putspent(spw, new);
    }
    // 获取下一个用户信息
    spw = fgetspent(old);
  }

  // 关闭文件
  fclose(old);
  fclose(new);
  // 关闭文件描述符
  close(old_fd);
  close(new_fd);

  // 删除/etc/shadow的备份
  unlink("/etc/shadow~");
  // 释放锁
  ulckpwdf();
}

// 解析命令行参数
// 返回结构体，设置适当的标志
  static pwgen_args parse_args(int argc, char* argv[]) {
  // 缓冲区
  char args_message_buffer[FILENAME_SZ];
  // 结构体
  pwgen_args args;
  // 缓冲区
  char buffer[BUFF_SZ];
  // 参数
  int c, res;

  struct option long_options[] = {
    {"salt", required_argument, NULL, 's'},
    {"seed", optional_argument, NULL, 'e'},
    {"type", required_argument, NULL, 't'},
    {"write", no_argument, NULL, 'w'},
    {"help", no_argument, NULL, 'h'},
    {0, 0, 0, 0}
  };
  // 初始化help
  help = 0;
  // 初始化args
  memset(&args, 0, sizeof(pwgen_args));
  // 初始化c
  c = 0;
  // 遍历参数
  while (1) {
    // 获取参数
    c = getopt_long(argc, argv, "s:e::t::wh", long_options, NULL);
    // 如果参数结束
    if (c == -1) break;

    switch (c) {
      // 参数为e
      case 'e':
        // 如果optarg不为空
        if (optarg) {
          // 将optarg复制到args.filename
          strncpy(args.filename, optarg, FILENAME_SZ);
        } else {
          // 检查文件权限
          res = check_perms();
          // 如果文件已存在
          if (res) {
            // 打印错误信息
            snprintf(buffer, 1024, "WARNING: '%s' could not create '%s' because the file already exists! :(\n", argv[0], FILENAME);
            fprintf(stderr, buffer);
            // 退出程序
            break;
          } else {
            // 将FILENAME复制到args.filename
            strcpy(args.filename, FILENAME);
            // 填充熵
            fill_entropy();
          }
        }
        // 将args.filename复制到args_message_buffer
        sprintf(args_message_buffer, args.filename);
        // 打印熵文件名
        printf("Entropy file name is: %s", args_message_buffer);
        break;
      // 参数为s
      case 's':
        // 将optarg复制到args.salt
        strncpy(args.salt, optarg, SALT_SZ);
        break;
      // 参数为t
      case 't':
        // 将optarg转换为整数并设置到args.type
        args.type = atoi(optarg);
        break;
      // 参数为h
      case 'h':
        // 设置help
        help = 1;
        break;
      // 参数为w
      case 'w':
        args.write = 1;
        break;
      // 参数为其他
        default:
        // 设置help
        help = 1;
        break;
    }
    // 如果help
        if (help) break;
  }
  // 如果盐为空
  if (strlen(args.salt) == 0) gen_salt(args.salt);
  // 返回args
  return args;
}

// 打印用法 
static void print_usage(char* arg) {
  // 缓冲区
  char buffer[1024];
  // 将用法信息复制到buffer
  snprintf(buffer, 1024, "Description: Randomly generates a password, optionally writes it to /etc/shadow\n"
      "\n"
      "Available options:\n"
      "-s<salt>, --salt=<salt> Specify custom salt (default is random)\n"
      "-e[file], --seed[=file] Specify custom seed from file; if flag set and none specified, file is stdin\n"
      "-t<type>, --type=<type> Specify hashing method\n"
      "-w      , --write       Update the /etc/shadow file\n"
      "-h      , --help        Show this usage message\n"
      "\n"
      "Hashing algorithm types:\n"
      "  0 - DES (default)\n"
      "  1 - MD5\n"
      "  2 - Blowfish\n"
      "  3 - SHA-256\n"
      "  4 - SHA-512\n"
      "------------------ End Usage for %s\0", arg);
  // 设置缓冲区最后一个字符为0
  buffer[BUFF_SZ - 1] = 0;
  // 打印用法
  printf("%s\n", buffer);
}

// 主函数
int main(int argc, char* argv[]) {
  // 结构体
  pwgen_args args;
  // 缓冲区
  char passwd[PASSWD_SZ+1], *crypt;
  args = parse_args(argc, argv);

  // 如果help
  if (help != 0) {
    // 打印用法
    print_usage(argv[0]);
    // 退出程序
    return 1;
  }

  // 清空passwd
  memset(passwd, 0, sizeof(passwd));
  // 生成密码
  gen_passwd(args, passwd);
  // 打印密码
  printf("Generated password (length %d): %s\n", PASSWD_SZ, passwd);

  // 如果write为0
    if (args.write == 0) {
    // 清空passwd
    memset(passwd, 0, sizeof(passwd));
  } else {
    // 生成密码的哈希
    crypt = gen_crypt(args, passwd);
    // 清空passwd
    memset(passwd, 0, sizeof(passwd));
    // 打印提示信息
    printf("Updating /etc/shadow...\n");
    // 更新/etc/shadow
    update_spent(crypt);
  }

  return 0;
}